/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Productos;

/**
 *
 * @author migue
 */
/* Clase abstracta genérica Producto
 * @param <T> Tipo genérico para la información adicional
 */
public abstract class Producto<T> { //abstract no permite que lo principal crea objetos
    private String nombre;
    private float precio;
    private T infomacion;

    public Producto(String nombre, float precio, T infomacion) {
        this.nombre = nombre;
        this.precio = precio;
        this.infomacion = infomacion;
    }
 
    public String getNombre() {
        return nombre;
    }


    public float getPrecio() {
        return precio;
    }

    public T getInfomacion() {
        return infomacion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public void setInfomacion(T infomacion) {
        this.infomacion = infomacion;
    }

    
    public abstract void mostrarDetalles();
    
    
}


