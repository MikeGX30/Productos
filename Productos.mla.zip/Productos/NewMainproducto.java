/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Productos;
import java.util.ArrayList;
/**
 *
 * @author migue
 */
public class NewMainproducto {


    public static void main(String[] args) {
        Producto<?>[] p1 = new Producto<?>[4];
        p1[0] = new Libro("JavaIluminated",600.0f,"460 Paginas");
        p1[1] = new Electronico("ASUS",12.198f,"2 años de garantia");
        p1[2] = new Libro("Patrones De Diseño",600.0f,"460 Paginas");
        p1[3] = new Electronico("Smartphone Samsung ",12.198f,"2 años de garantia");
        
        for (Producto<?> p: p1) {
            p.mostrarDetalles();
        }
    }
}